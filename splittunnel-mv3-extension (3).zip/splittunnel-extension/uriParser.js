/**
 * SplitTunnel - Universal V2Ray/Xray Config & Subscription Parser
 * Supports:
 * - Base64 subscriptions (multi-link feeds)
 * - Multi-line vless://, vmess://, trojan://, ss://, socks5://
 * - Full client JSON configurations
 */

export function decodeBase64Safe(b64) {
  const cleanB64 = b64.trim().replace(/-/g, '+').replace(/_/g, '/');
  const padLength = (4 - (cleanB64.length % 4)) % 4;
  const padded = cleanB64 + '='.repeat(padLength);
  
  try {
    const binary = atob(padded);
    const bytes = Uint8Array.from(binary, (m) => m.charCodeAt(0));
    return new TextDecoder('utf-8').decode(bytes);
  } catch {
    return atob(padded);
  }
}

export function parseVlessLink(uri) {
  const trimmed = uri.trim();
  if (!trimmed.toLowerCase().startsWith('vless://')) {
    throw new Error('Not a valid VLESS URI');
  }

  const withoutScheme = trimmed.slice(8);
  const hashIndex = withoutScheme.indexOf('#');
  let mainPart = withoutScheme;
  let remark = '';

  if (hashIndex !== -1) {
    mainPart = withoutScheme.substring(0, hashIndex);
    try {
      remark = decodeURIComponent(withoutScheme.substring(hashIndex + 1).trim());
    } catch {
      remark = withoutScheme.substring(hashIndex + 1).trim();
    }
  }

  const qIndex = mainPart.indexOf('?');
  let authority = mainPart;
  let params = new URLSearchParams();

  if (qIndex !== -1) {
    authority = mainPart.substring(0, qIndex);
    params = new URLSearchParams(mainPart.substring(qIndex + 1));
  }

  const atIndex = authority.indexOf('@');
  if (atIndex === -1) {
    throw new Error('Invalid VLESS format: missing @');
  }

  const uuid = authority.substring(0, atIndex);
  const hostPort = authority.substring(atIndex + 1);

  let host = hostPort;
  let port = 443;

  if (hostPort.includes(':')) {
    const colonIndex = hostPort.lastIndexOf(':');
    host = hostPort.substring(0, colonIndex);
    port = parseInt(hostPort.substring(colonIndex + 1), 10) || 443;
  }

  if (host.startsWith('[') && host.endsWith(']')) {
    host = host.slice(1, -1);
  }

  const transport = params.get('type') || params.get('net') || 'tcp';
  const security = params.get('security') || 'none';
  const flow = params.get('flow') || '';
  const sni = params.get('sni') || params.get('host') || host;
  const path = params.get('path') ? decodeURIComponent(params.get('path')) : '';
  const pbk = params.get('pbk') || '';
  const sid = params.get('sid') || '';
  const fp = params.get('fp') || 'chrome';
  const alpn = params.get('alpn') ? decodeURIComponent(params.get('alpn')) : '';

  return {
    id: 'vless_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
    name: remark || `VLESS ${host}:${port}`,
    protocol: 'vless',
    host,
    port,
    uuid,
    transport,
    security,
    flow,
    sni,
    path,
    publicKey: pbk,
    shortId: sid,
    fingerprint: fp,
    bypassList: ['<local>', '127.0.0.1', '::1', '*.local', '192.168.0.0/16', '10.0.0.0/8'],
    isV2RayBridge: true,
    rawUri: trimmed,
    notes: `VLESS via ${transport.toUpperCase()}${security ? ' + ' + security.toUpperCase() : ''}${alpn ? ` (ALPN: ${alpn})` : ''}`
  };
}

export function parseVmessLink(uri) {
  const trimmed = uri.trim();
  if (!trimmed.toLowerCase().startsWith('vmess://')) {
    throw new Error('Not a valid VMess URI');
  }

  const b64 = trimmed.slice(8);
  const decoded = decodeBase64Safe(b64);
  const json = JSON.parse(decoded);

  const host = json.add;
  const port = parseInt(json.port, 10) || 443;
  const uuid = json.id;
  const remark = json.ps || `VMess ${host}:${port}`;
  const transport = json.net || 'tcp';
  const security = json.tls || 'none';
  const sni = json.sni || json.host || host;
  const path = json.path || '';
  const alterId = parseInt(json.aid, 10) || 0;

  return {
    id: 'vmess_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
    name: remark,
    protocol: 'vmess',
    host,
    port,
    uuid,
    alterId,
    transport,
    security,
    sni,
    path,
    fingerprint: json.fp || 'chrome',
    bypassList: ['<local>', '127.0.0.1', '::1', '*.local', '192.168.0.0/16', '10.0.0.0/8'],
    isV2RayBridge: true,
    rawUri: trimmed,
    notes: `VMess via ${transport.toUpperCase()}`
  };
}

export function parseTrojanLink(uri) {
  const trimmed = uri.trim();
  if (!trimmed.toLowerCase().startsWith('trojan://')) {
    throw new Error('Not a valid Trojan URI');
  }

  const withoutScheme = trimmed.slice(9);
  const hashIndex = withoutScheme.indexOf('#');
  let mainPart = withoutScheme;
  let remark = '';

  if (hashIndex !== -1) {
    mainPart = withoutScheme.substring(0, hashIndex);
    try {
      remark = decodeURIComponent(withoutScheme.substring(hashIndex + 1).trim());
    } catch {
      remark = withoutScheme.substring(hashIndex + 1).trim();
    }
  }

  const qIndex = mainPart.indexOf('?');
  let authority = mainPart;
  let params = new URLSearchParams();

  if (qIndex !== -1) {
    authority = mainPart.substring(0, qIndex);
    params = new URLSearchParams(mainPart.substring(qIndex + 1));
  }

  const atIndex = authority.indexOf('@');
  if (atIndex === -1) {
    throw new Error('Invalid Trojan format: missing @');
  }

  const password = authority.substring(0, atIndex);
  const hostPort = authority.substring(atIndex + 1);

  let host = hostPort;
  let port = 443;

  if (hostPort.includes(':')) {
    const colonIndex = hostPort.lastIndexOf(':');
    host = hostPort.substring(0, colonIndex);
    port = parseInt(hostPort.substring(colonIndex + 1), 10) || 443;
  }

  const sni = params.get('sni') || params.get('host') || host;
  const security = params.get('security') || 'tls';
  const transport = params.get('type') || 'tcp';
  const path = params.get('path') ? decodeURIComponent(params.get('path')) : '';
  const alpn = params.get('alpn') ? decodeURIComponent(params.get('alpn')) : '';

  return {
    id: 'trojan_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
    name: remark || `Trojan ${host}:${port}`,
    protocol: 'trojan',
    host,
    port,
    password,
    sni,
    security,
    transport,
    path,
    bypassList: ['<local>', '127.0.0.1', '::1', '*.local'],
    isV2RayBridge: true,
    rawUri: trimmed,
    notes: `Trojan via ${transport.toUpperCase()} + ${security.toUpperCase()}${alpn ? ` (ALPN: ${alpn})` : ''}`
  };
}

export function parseSingleShareLink(input) {
  const trimmed = input.trim();
  if (trimmed.startsWith('vless://')) return parseVlessLink(trimmed);
  if (trimmed.startsWith('vmess://')) return parseVmessLink(trimmed);
  if (trimmed.startsWith('trojan://')) return parseTrojanLink(trimmed);
  if (trimmed.startsWith('socks5://') || trimmed.startsWith('socks://')) {
    const url = new URL(trimmed);
    return {
      id: 'socks5_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      name: decodeURIComponent(url.hash.replace('#', '')) || `SOCKS5 ${url.hostname}:${url.port || 1080}`,
      protocol: 'socks5',
      host: url.hostname,
      port: parseInt(url.port, 10) || 1080,
      username: url.username ? decodeURIComponent(url.username) : '',
      password: url.password ? decodeURIComponent(url.password) : '',
      bypassList: ['<local>', '127.0.0.1', '::1', '*.local'],
      isV2RayBridge: url.hostname === '127.0.0.1' && (url.port === '10808' || url.port === '10809'),
      rawUri: trimmed
    };
  }
  throw new Error('Unsupported URI format: ' + trimmed.substring(0, 30));
}

/**
 * Universal Multi-Config & Base64 Subscription Parser
 */
export function parseAnyV2RayConfig(rawText) {
  const trimmed = rawText.trim();
  if (!trimmed) return [];

  // Check if it is a Base64 subscription bundle
  if (!trimmed.includes('://') && !trimmed.startsWith('{') && /^[-A-Za-z0-9+/=_\s]+$/.test(trimmed)) {
    try {
      const decoded = decodeBase64Safe(trimmed);
      if (decoded.includes('://')) {
        return parseAnyV2RayConfig(decoded);
      }
    } catch {
      // continue
    }
  }

  // Parse line-by-line
  const lines = trimmed.split(/[\r\n]+/).map(l => l.trim()).filter(Boolean);
  const profiles = [];

  for (const line of lines) {
    if (!line.includes('://') && /^[-A-Za-z0-9+/=_]+$/.test(line)) {
      try {
        const dec = decodeBase64Safe(line);
        if (dec.includes('://')) {
          profiles.push(...parseAnyV2RayConfig(dec));
          continue;
        }
      } catch {
        // continue
      }
    }

    try {
      const p = parseSingleShareLink(line);
      profiles.push(p);
    } catch {
      // skip invalid lines
    }
  }

  if (profiles.length === 0) {
    throw new Error('No valid V2Ray/Xray configs found');
  }

  return profiles;
}

export function parseShareLink(input) {
  return parseAnyV2RayConfig(input)[0];
}
