/**
 * SplitTunnel Proxy Client - Background Service Worker (Manifest V3)
 */

chrome.runtime.onInstalled.addListener(async () => {
  const data = await chrome.storage.local.get(['profiles', 'activeProfileId', 'isConnected']);
  if (!data.profiles || data.profiles.length === 0) {
    const defaultProfile = {
      id: 'v2ray-local-socks5',
      name: 'V2Ray / Xray Local Core (SOCKS5)',
      protocol: 'socks5',
      host: '127.0.0.1',
      port: 10808,
      username: '',
      password: '',
      bypassList: ['<local>', '127.0.0.1', '::1', '*.local', '192.168.0.0/16', '10.0.0.0/8'],
      isV2RayBridge: true
    };
    await chrome.storage.local.set({
      profiles: [defaultProfile],
      activeProfileId: defaultProfile.id,
      isConnected: false
    });
  }
  updateBadge(false);
});

async function applyProxy(profile) {
  if (!profile) throw new Error('No profile provided');

  const isV2Ray = profile.isV2RayBridge || ['vless', 'vmess', 'trojan'].includes(profile.protocol);
  const scheme = isV2Ray ? 'socks5' : profile.protocol;
  const host = isV2Ray ? '127.0.0.1' : profile.host;
  const port = isV2Ray ? 10808 : parseInt(profile.port, 10);

  const config = {
    mode: 'fixed_servers',
    rules: {
      singleProxy: { scheme, host, port },
      bypassList: Array.isArray(profile.bypassList) && profile.bypassList.length > 0
        ? profile.bypassList
        : ['<local>', '127.0.0.1', '::1']
    }
  };

  return new Promise((resolve, reject) => {
    chrome.proxy.settings.set({ value: config, scope: 'regular' }, () => {
      if (chrome.runtime.lastError) {
        console.error('[SplitTunnel] Failed to set proxy:', chrome.runtime.lastError);
        reject(chrome.runtime.lastError);
      } else {
        console.log(`[SplitTunnel] Proxy applied: ${scheme}://${host}:${port}`);
        resolve();
      }
    });
  });
}

async function clearProxy() {
  return new Promise((resolve, reject) => {
    chrome.proxy.settings.clear({ scope: 'regular' }, () => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        console.log('[SplitTunnel] Proxy cleared. Restored system routing.');
        resolve();
      }
    });
  });
}

function updateBadge(isConnected, profileName = '') {
  if (isConnected) {
    chrome.action.setBadgeText({ text: 'ON' });
    chrome.action.setBadgeBackgroundColor({ color: '#10B981' });
    chrome.action.setTitle({
      title: `SplitTunnel: Connected to ${profileName || 'Proxy'}\n(Browser isolated from OS VPN)`
    });
  } else {
    chrome.action.setBadgeText({ text: '' });
    chrome.action.setTitle({ title: 'SplitTunnel: Disconnected (Default routing)' });
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'CONNECT_PROXY') {
    handleConnect(message.profileId)
      .then(() => sendResponse({ success: true }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }
  if (message.type === 'DISCONNECT_PROXY') {
    handleDisconnect()
      .then(() => sendResponse({ success: true }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }
});

async function handleConnect(profileId) {
  const data = await chrome.storage.local.get(['profiles', 'activeProfileId']);
  const targetId = profileId || data.activeProfileId;
  const profile = data.profiles?.find(p => p.id === targetId);

  if (!profile) throw new Error('Profile not found: ' + targetId);

  await applyProxy(profile);
  await chrome.storage.local.set({ isConnected: true, activeProfileId: profile.id });
  updateBadge(true, profile.name);
}

async function handleDisconnect() {
  await clearProxy();
  await chrome.storage.local.set({ isConnected: false });
  updateBadge(false);
}

chrome.webRequest.onAuthRequired.addListener(
  (details, callback) => {
    if (!details.isProxy) {
      callback({});
      return;
    }
    chrome.storage.local.get(['isConnected', 'activeProfileId', 'profiles'], (data) => {
      if (!data.isConnected) {
        callback({});
        return;
      }
      const active = data.profiles?.find(p => p.id === data.activeProfileId);
      if (active && active.username) {
        callback({
          authCredentials: {
            username: active.username,
            password: active.password || ''
          }
        });
      } else {
        callback({});
      }
    });
  },
  { urls: ['<all_urls>'] },
  ['asyncBlocking']
);
