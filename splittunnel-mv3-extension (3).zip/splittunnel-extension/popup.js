/**
 * SplitTunnel Proxy Client - Popup Controller
 * Integrated with Universal Subscription & Config Parsing Engine
 */
import { parseAnyV2RayConfig } from './uriParser.js';

const masterToggle = document.getElementById('master-toggle');
const statusDot = document.getElementById('status-dot');
const statusText = document.getElementById('status-text');
const statusDesc = document.getElementById('status-desc');
const profileSelect = document.getElementById('profile-select');
const addMenuBtn = document.getElementById('add-menu-btn');
const quickImportPanel = document.getElementById('quick-import-panel');
const pasteClipboardBtn = document.getElementById('paste-clipboard-btn');
const openOptionsBtn = document.getElementById('open-options-btn');
const detailProtocol = document.getElementById('detail-protocol');
const detailEndpoint = document.getElementById('detail-endpoint');
const detailTunnel = document.getElementById('detail-tunnel');
const pingBtn = document.getElementById('ping-btn');
const pingText = document.getElementById('ping-text');
const toast = document.getElementById('toast');

let profiles = [];
let activeProfileId = null;
let isConnected = false;

document.addEventListener('DOMContentLoaded', async () => {
  await loadState();
  bindEvents();
});

async function loadState() {
  const data = await chrome.storage.local.get(['profiles', 'activeProfileId', 'isConnected']);
  profiles = data.profiles || [];
  activeProfileId = data.activeProfileId || profiles[0]?.id;
  isConnected = !!data.isConnected;

  renderProfilesDropdown();
  updateUI();
}

function renderProfilesDropdown() {
  profileSelect.innerHTML = '';
  
  if (profiles.length === 0) {
    const opt = document.createElement('option');
    opt.value = '';
    opt.textContent = 'No profiles saved';
    profileSelect.appendChild(opt);
    return;
  }

  profiles.forEach(p => {
    const opt = document.createElement('option');
    opt.value = p.id;
    const protoTag = (p.protocol || 'SOCKS5').toUpperCase();
    opt.textContent = `${p.name} (${protoTag})`;
    if (p.id === activeProfileId) opt.selected = true;
    profileSelect.appendChild(opt);
  });
}

function updateUI() {
  masterToggle.checked = isConnected;
  const current = profiles.find(p => p.id === activeProfileId) || profiles[0];

  if (isConnected) {
    statusDot.className = 'status-indicator connected';
    statusText.textContent = 'Connected (Proxy Active)';
    statusDesc.textContent = 'Browser isolated from OS VPN';
    statusDesc.className = 'status-sub text-emerald';
  } else {
    statusDot.className = 'status-indicator disconnected';
    statusText.textContent = 'Disconnected';
    statusDesc.textContent = 'Standard OS routing';
    statusDesc.className = 'status-sub';
  }

  if (current) {
    detailProtocol.textContent = (current.protocol || 'SOCKS5').toUpperCase();
    if (current.isV2RayBridge || ['vless', 'vmess', 'trojan'].includes(current.protocol)) {
      detailEndpoint.textContent = `${current.host}:${current.port} (via 127.0.0.1:10808)`;
      detailTunnel.textContent = 'Local V2Ray / Xray Bridge';
    } else {
      detailEndpoint.textContent = `${current.host}:${current.port}`;
      detailTunnel.textContent = 'Browser Only (Overrides OS VPN)';
    }
  } else {
    detailProtocol.textContent = 'None';
    detailEndpoint.textContent = 'N/A';
    detailTunnel.textContent = 'Standard Routing';
  }
}

/**
 * Universal Clipboard Import:
 * Handles single links, multi-line links, and Base64 subscription feeds
 */
async function handlePasteFromClipboard() {
  quickImportPanel.classList.add('hidden');

  try {
    const text = await navigator.clipboard.readText();
    if (!text || !text.trim()) {
      showToast('Clipboard is empty', true);
      return;
    }

    // Parse any V2Ray/Xray config (Base64 subscription or raw share links)
    const newProfiles = parseAnyV2RayConfig(text.trim());

    if (newProfiles.length === 0) {
      showToast('No valid V2Ray/Xray links found', true);
      return;
    }

    // Merge with existing
    profiles.unshift(...newProfiles);
    activeProfileId = newProfiles[0].id;
    await chrome.storage.local.set({ profiles, activeProfileId });

    renderProfilesDropdown();
    updateUI();

    if (newProfiles.length === 1) {
      showToast(`Imported: ${newProfiles[0].name}`);
    } else {
      showToast(`Imported ${newProfiles.length} servers from subscription bundle!`);
    }

    if (isConnected) {
      chrome.runtime.sendMessage({ type: 'CONNECT_PROXY', profileId: activeProfileId });
    }
  } catch (err) {
    console.error('Clipboard import failed:', err);
    showToast('Import failed: ' + (err.message || 'Invalid format'), true);
  }
}

function bindEvents() {
  addMenuBtn.addEventListener('click', () => {
    quickImportPanel.classList.toggle('hidden');
  });

  document.addEventListener('click', (e) => {
    if (!addMenuBtn.contains(e.target) && !quickImportPanel.contains(e.target)) {
      quickImportPanel.classList.add('hidden');
    }
  });

  pasteClipboardBtn.addEventListener('click', handlePasteFromClipboard);

  masterToggle.addEventListener('change', () => {
    if (masterToggle.checked) {
      if (!activeProfileId) {
        showToast('Please select or paste a server profile first', true);
        masterToggle.checked = false;
        return;
      }

      chrome.runtime.sendMessage(
        { type: 'CONNECT_PROXY', profileId: activeProfileId },
        (res) => {
          if (res?.success) {
            isConnected = true;
            updateUI();
            showToast('Proxy active. Browser split-tunneling enabled.');
          } else {
            masterToggle.checked = false;
            showToast('Connection failed: ' + (res?.error || 'Unknown error'), true);
          }
        }
      );
    } else {
      chrome.runtime.sendMessage({ type: 'DISCONNECT_PROXY' }, () => {
        isConnected = false;
        updateUI();
        showToast('Proxy disconnected. System routing restored.');
      });
    }
  });

  profileSelect.addEventListener('change', async () => {
    activeProfileId = profileSelect.value;
    await chrome.storage.local.set({ activeProfileId });
    updateUI();

    if (isConnected) {
      chrome.runtime.sendMessage({ type: 'CONNECT_PROXY', profileId: activeProfileId }, () => {
        showToast('Switched to: ' + (profiles.find(p => p.id === activeProfileId)?.name));
      });
    }
  });

  openOptionsBtn.addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });

  pingBtn.addEventListener('click', async () => {
    pingText.textContent = 'Measuring...';
    const start = performance.now();
    try {
      const res = await fetch('https://1.1.1.1/cdn-cgi/trace', { cache: 'no-store' });
      if (res.ok) {
        const ms = Math.round(performance.now() - start);
        pingText.textContent = `${ms} ms latency`;
      } else {
        pingText.textContent = 'HTTP Err';
      }
    } catch {
      pingText.textContent = 'Unreachable';
    }
    setTimeout(() => { pingText.textContent = 'Check Latency'; }, 4000);
  });
}

function showToast(msg, isError = false) {
  toast.textContent = msg;
  toast.className = 'toast ' + (isError ? 'error' : 'success');
  setTimeout(() => { toast.className = 'toast hidden'; }, 3000);
}
