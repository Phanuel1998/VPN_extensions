/**
 * SplitTunnel Proxy Client - Options Page Logic
 */
import { parseAnyV2RayConfig } from './uriParser.js';

let profiles = [];
let activeProfileId = null;

const profilesContainer = document.getElementById('profiles-container');
const pasteBtnOptions = document.getElementById('paste-btn-options');
const toast = document.getElementById('toast');

document.addEventListener('DOMContentLoaded', async () => {
  await loadProfiles();
  bindEvents();
});

async function loadProfiles() {
  const data = await chrome.storage.local.get(['profiles', 'activeProfileId']);
  profiles = data.profiles || [];
  activeProfileId = data.activeProfileId || null;
  renderProfiles();
}

function renderProfiles() {
  profilesContainer.innerHTML = '';
  profiles.forEach(p => {
    const card = document.createElement('div');
    card.className = 'profile-card' + (p.id === activeProfileId ? ' active-border' : '');
    card.innerHTML = `
      <div class="profile-card-header">
        <div>
          <h3 class="profile-name">${escapeHtml(p.name)}</h3>
          <div class="pill-row">
            <span class="pill-badge protocol">${(p.protocol || 'SOCKS5').toUpperCase()}</span>
            ${p.isV2RayBridge ? '<span class="pill-badge v2ray">V2Ray Core</span>' : ''}
            ${p.id === activeProfileId ? '<span class="pill-badge active">Active</span>' : ''}
          </div>
        </div>
        <button class="icon-btn delete-btn" data-id="${p.id}" title="Delete Profile">&times;</button>
      </div>
      <div class="profile-meta">
        <div class="meta-item"><span class="meta-label">Host:</span><span class="meta-val">${escapeHtml(p.host)}:${p.port}</span></div>
        ${p.uuid ? `<div class="meta-item"><span class="meta-label">UUID:</span><span class="meta-val">${p.uuid.slice(0, 8)}...</span></div>` : ''}
        ${p.path ? `<div class="meta-item"><span class="meta-label">Path:</span><span class="meta-val">${escapeHtml(p.path.slice(0, 24))}...</span></div>` : ''}
      </div>
    `;
    card.querySelector('.delete-btn').addEventListener('click', () => deleteProfile(p.id));
    profilesContainer.appendChild(card);
  });
}

async function deleteProfile(id) {
  profiles = profiles.filter(p => p.id !== id);
  await chrome.storage.local.set({ profiles });
  renderProfiles();
}

function bindEvents() {
  pasteBtnOptions?.addEventListener('click', async () => {
    try {
      const text = await navigator.clipboard.readText();
      const parsedList = parseAnyV2RayConfig(text);
      profiles.unshift(...parsedList);
      activeProfileId = parsedList[0].id;
      await chrome.storage.local.set({ profiles, activeProfileId });
      renderProfiles();
      showToast(`Imported ${parsedList.length} node(s)!`);
    } catch (e) {
      showToast('Paste error: ' + e.message, true);
    }
  });
}

function escapeHtml(str) {
  return (str || '').replace(/[&<>'"]/g, tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag));
}

function showToast(msg, isError = false) {
  toast.textContent = msg;
  toast.className = 'toast ' + (isError ? 'error' : 'success');
  setTimeout(() => { toast.className = 'toast hidden'; }, 3000);
}
