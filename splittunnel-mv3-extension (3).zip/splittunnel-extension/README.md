# SplitTunnel: Manifest V3 Browser VPN & Proxy Client

Engineered with a **Universal V2Ray Subscription & Multi-Link Parser** for **browser-level split tunneling**.

## Features

1. **Any V2Ray Config Support**:
   - Decodes Base64 subscription feeds (e.g. `dmxlc3M6...`)
   - Decodes multi-line VLESS, VMess, Trojan, and SOCKS5 lists
   - Decodes Cloudflare Worker WebSocket tunnels (with `ed=2560` early data)
   - Decodes VLESS Reality and Trojan TLS
2. **One-Click Clipboard Auto-Import**:
   - Click the **+** button in the popup header.
   - Click **Paste config from clipboard** to import all nodes at once into `chrome.storage.local`.
